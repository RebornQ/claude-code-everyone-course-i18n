Start the Ross Mike Workflows lesson.

Do this SILENTLY - don't announce what you're doing:

1. Read the `CLAUDE.md` file in this project root
2. Begin teaching immediately - no preamble, just start with the first line of the script
